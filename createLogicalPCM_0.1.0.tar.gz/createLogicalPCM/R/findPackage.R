#' @title Find CRAN Package by topic
#'
#' @description Finds CRAN packages by the topic requested. The topic can be given as a character string or as a regular expression, and will help users to locate packages according to their requirement.
#' @param topicString The topic as a character string or as a regular expression
#' @param fromDate  Format: YYYY-MM-DD. The search in CRAN will be restricted to packages published on or after this date, default is from the earliest available date, i.e. September 2008
#' @param toDate    Format: YYYY-MM-DD. The search in CRAN will be restricted to packages published on or before this date, default is till the current date
#' @param sortOrder The matching data is sorted by default (A) with the earlier published packages preceding the later ones. For descending sort, more recent earlier, use "D"
#' @return A data frame with the package name, its title and the date of publication
#' @importFrom stats runif
#' @examples
#' lPCM <- createLogicalPCM(3,c(1,2,3));
#' lPCM <- createLogicalPCM(5,c(0.25,0.4,0.1,0.05,0.2));
#' @export
findPackage <- function(topicString, fromDate="2008-09-01", toDate=Sys.Date(), sortOrder="A") {
  # if (is.na(ord)) stop("The first parameter is mandatory")
  # if (!is.numeric(ord) || ord %% 1 != 0) stop("The first parameter has to be an integer")
  # if (!all(is.na(prefVec)) && !is.numeric(prefVec)) stop("The second parameter has to be a numeric vector")
  # if (!all(is.na(prefVec)) && length(prefVec)!=ord) stop("The length of the second parameter has to be the same as the first parameter")

  db <- tools::CRAN_package_db()
  rows <- grep(topicString, db$Description)
  db <- db[rows,c("Package", "Date/Publication", "Title")]
  db$`Date/Publication` <- sub("^([^ ]+).*", "\\1", db$`Date/Publication`)
  db <- db[db$`Date/Publication` >= fromDate & db$`Date/Publication` <= toDate,]
  if (sortOrder=="A") {
    db <- db[order(db$`Date/Publication`,decreasing=FALSE),]
  } else {
    db <- db[order(db$`Date/Publication`,decreasing=TRUE),]
  }

  return(db)
}

